﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.Pertemuan2ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PesanToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Slide18ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Pertemuan2ToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.Slide7ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Slide12ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Slide14ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Slide15ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Slide16ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Pertemuan2ToolStripMenuItem, Me.Pertemuan2ToolStripMenuItem1})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(800, 24)
        Me.MenuStrip1.TabIndex = 0
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'Pertemuan2ToolStripMenuItem
        '
        Me.Pertemuan2ToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.PesanToolStripMenuItem, Me.Slide18ToolStripMenuItem})
        Me.Pertemuan2ToolStripMenuItem.Name = "Pertemuan2ToolStripMenuItem"
        Me.Pertemuan2ToolStripMenuItem.Size = New System.Drawing.Size(86, 20)
        Me.Pertemuan2ToolStripMenuItem.Text = "Pertemuan 1"
        '
        'PesanToolStripMenuItem
        '
        Me.PesanToolStripMenuItem.Name = "PesanToolStripMenuItem"
        Me.PesanToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.PesanToolStripMenuItem.Text = "Pesan"
        '
        'Slide18ToolStripMenuItem
        '
        Me.Slide18ToolStripMenuItem.Name = "Slide18ToolStripMenuItem"
        Me.Slide18ToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.Slide18ToolStripMenuItem.Text = "Slide 18"
        '
        'Pertemuan2ToolStripMenuItem1
        '
        Me.Pertemuan2ToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Slide7ToolStripMenuItem, Me.Slide12ToolStripMenuItem, Me.Slide14ToolStripMenuItem, Me.Slide15ToolStripMenuItem, Me.Slide16ToolStripMenuItem})
        Me.Pertemuan2ToolStripMenuItem1.Name = "Pertemuan2ToolStripMenuItem1"
        Me.Pertemuan2ToolStripMenuItem1.Size = New System.Drawing.Size(86, 20)
        Me.Pertemuan2ToolStripMenuItem1.Text = "Pertemuan 2"
        '
        'Slide7ToolStripMenuItem
        '
        Me.Slide7ToolStripMenuItem.Name = "Slide7ToolStripMenuItem"
        Me.Slide7ToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.Slide7ToolStripMenuItem.Text = "Slide 7"
        '
        'Slide12ToolStripMenuItem
        '
        Me.Slide12ToolStripMenuItem.Name = "Slide12ToolStripMenuItem"
        Me.Slide12ToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.Slide12ToolStripMenuItem.Text = "Slide 12"
        '
        'Slide14ToolStripMenuItem
        '
        Me.Slide14ToolStripMenuItem.Name = "Slide14ToolStripMenuItem"
        Me.Slide14ToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.Slide14ToolStripMenuItem.Text = "Slide 14"
        '
        'Slide15ToolStripMenuItem
        '
        Me.Slide15ToolStripMenuItem.Name = "Slide15ToolStripMenuItem"
        Me.Slide15ToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.Slide15ToolStripMenuItem.Text = "Slide 15"
        '
        'Slide16ToolStripMenuItem
        '
        Me.Slide16ToolStripMenuItem.Name = "Slide16ToolStripMenuItem"
        Me.Slide16ToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.Slide16ToolStripMenuItem.Text = "Slide 16"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents Pertemuan2ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PesanToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Slide18ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Pertemuan2ToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents Slide7ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Slide12ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Slide14ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Slide15ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Slide16ToolStripMenuItem As ToolStripMenuItem
End Class
