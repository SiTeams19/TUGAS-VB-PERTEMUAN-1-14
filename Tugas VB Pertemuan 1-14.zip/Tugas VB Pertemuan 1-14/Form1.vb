﻿Public Class Form1
    Private Sub Pertemuan1ToolStripMenuItem_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Slide7ToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles Slide7ToolStripMenuItem.Click

    End Sub
End Class
